﻿1. NỘI DUNG: Điều chỉnh số lần in ra bill theo số lần giới hạn do người dùng cài đặt trong phần Enterprise
2. Điều kiện tiên quyết 
Truy cập theo đường dẫn để tạo UDF:  Administration > Application Setup > User Defined Fields. 
- Object Type: chọn	Enterprise
- Field Name: Đặt U_LimitPrintNumber
- Check vào: Display in Results(Cho phép trường tạo hiển thị trong Enterprise)
- Mở Enterprise nhập số lượng giới hạn in
