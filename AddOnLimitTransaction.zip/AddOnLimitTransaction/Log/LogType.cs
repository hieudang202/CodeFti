﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddOnLimitTransaction.Log
{
    public enum LogType
    {
        INFOR,
        WARRING,
        ERROR
    }
}
